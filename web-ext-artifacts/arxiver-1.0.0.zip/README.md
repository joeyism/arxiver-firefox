# arxiver-firefox
Handy tool for Arxiv. Allows you to save Arxiv files for later viewing. Has a search functionality too.
